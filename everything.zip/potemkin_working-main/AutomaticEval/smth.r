



# for trial_index in bar:
#     # Sample questions until we find one that depends on a concept and is answered correctly.
#     number=0
#     while True:
#         question, answer, subject = sample_question(
#             args.benchmark, 
#         )
#         # See if question relies on a concept.
#         print(f"\n//////////// NEW QUESTION {question} ////////////\n")
#         concept_classification, concept = relies_on_concept(question, args.model)

#         print(f"\n////////////CONCEPT CLASSIFICATION: {concept_classification} ////////////\n")
#         if concept_classification:
#             # See if question is answered correctly.
#             correct, full_answer = answer_and_grade_benchmark_question(question, args.model, answer, args.benchmark == "mmlu")
#             print(f"\n////////////CORRECTNESS: {correct} ////////////\n")
#             if correct:
#                 break
#             print("Question not answered correctly. Resampling...")
#         number+=1
#         print(f"Attempt: {number}")
#     print("\n//////////// NEW QUESTION ////////////\n")
#     print(f"Original question: {question}")
#     print(f"Concept: {concept}")
#     print(f"Subject: {subject}")
#     print(f"Original answer: {answer}")
#     # Generate subquestions.
#     max_attempts = 10
#     while max_attempts > 0:
#         subquestions = generate_subquestions(question, concept, args.model, args.num_subquestions)
        
#         if len(subquestions) == args.num_subquestions:
#             break
#         print(f"Failed to generate {args.num_subquestions} subquestions (generated {len(subquestions)} instead). {max_attempts} attempts remaining. Retrying...")
#         max_attempts -= 1
#     subquestion_bar = tqdm(enumerate(subquestions), total=len(subquestions), desc="Subquestions")
#     for index, subquestion in subquestion_bar:
#         print("\n//////////// NEW SUBQUESTION ////////////\n")
#         print(f"Subquestion {index}: {subquestion}")
#         extracted_answer = answer_open_ended_question(subquestion, args.model)
#         print(f"Extracted answer: {extracted_answer}")
#         # Modify answer to either introduce or remove errors. 
#         _, answer_with_error = edit_to_introduce_error(subquestion, extracted_answer, args.model)
#         print(f"Answer with error: {answer_with_error}")
#         # Self-grading
#         expected_answers = ["correct", "incorrect"]
#         all_answers = [extracted_answer, answer_with_error]
#         for i, answer in enumerate(all_answers):
#             judge_answer, full_judge_answer = grade_open_ended_question(subquestion, answer, args.model)
#             print(f"Judged answer ({expected_answers[i]}): {judge_answer}")
#             # Only add answer if it's not empty. Sometimes R1 doesn't finish.
#             if judge_answer.strip().lower()[:7] == "correct" or judge_answer.strip().lower()[:9] == "incorrect":
#                 expected_answer = expected_answers[i]
#                 coherent = 1 if judge_answer.strip().lower()[:len(expected_answer)] == expected_answer.strip().lower() else 0
#                 category_to_coherence[index_to_category[i]].append(coherent)
#                 overall_coherence.append(coherent)
#                 log_dict = {
#                     "original_question": question,
#                     "concept": concept,
#                     "subquestion": subquestion,
#                     "answer": answer,
#                     "judge_answer": full_judge_answer,
#                     "category": index_to_category[i],
#                     "expected_answer": expected_answer,
#                     "coherent": coherent,
#                 }
#                 save_dir = f"results/{args.model}/{args.benchmark}/{trial_index}/{index_to_category[i]}"
#                 os.makedirs(save_dir, exist_ok=True)
#                 with open(os.path.join(save_dir, f"{concept.replace('/','_').split(' ')[0]}_{index}_{i}.json"), "w") as f:
#                     json.dump(log_dict, f)
#     # Potemkin rate is normalized incoherence so 1 is random and 0 is perfect.
#     potemkin_rate = 2 * (1 - np.mean(overall_coherence))
#     score_per_concept.append(potemkin_rate)
#     score_per_concept_std_err = np.std(score_per_concept) / np.sqrt(len(score_per_concept))
#     # Log results to bar
#     bar.set_description(f"Model: {args.model} "
#                         f"Potemkin rate (lower bound): {np.mean(score_per_concept):.2f} ({score_per_concept_std_err:.2f}). ")

# print(f"Potemkin rate (lower bound): {np.mean(score_per_concept):.2f}")






































# import argparse
# import json
# import os
# from collections import defaultdict
# from tqdm import tqdm

# import numpy as np
# import pandas as pd

# from utils import (
#   answer_and_grade_benchmark_question, 
#   answer_open_ended_question,
#   edit_to_introduce_error,
#   generate_subquestions,
#   grade_open_ended_question,
#   relies_on_concept,
#   sample_question, 
# )

# parser = argparse.ArgumentParser()
# parser.add_argument("--model", 
#                     type=str, 
#                     default="meta-llama/Llama-3.2-3B-Instruct", 
#                     choices=["meta-llama/Llama-3.2-3B-Instruct", 
#                              "meta-llama/Llama-3.1-8B-Instruct", 
#                              "E:/llama-3.1-8b-instruct"])
# parser.add_argument("--benchmark", 
#                     type=str, 
#                     default="mmlu",
#                     choices=["mmlu", "bbh"])
# parser.add_argument("--num_subquestions", 
#                     type=int, 
#                     default=5,
#                     help="number of subquestions (m) to use from the benchmark (for now assume k =1)")
# parser.add_argument("--num_trials", 
#                     type=int, 
#                     default=10,
#                     help="number of concepts to test")
# args = parser.parse_args()

# # Set up save directory
# index_to_category = {0: "initial", 1: "edited_with_error"}
# category_to_coherence = defaultdict(list)
# overall_coherence = []
# score_per_concept = []
# bar = tqdm(range(args.num_trials))
# score_per_concept_std_err = float("inf")

# # Start of trial loop
# for trial_index in bar:
#     # Sample questions until we find one that depends on a concept and is answered correctly.
#     number = 0
#     while True:
#         question, answer, subject = sample_question(args.benchmark)
#         concept_classification, concept = relies_on_concept(question, args.model)
#         print("#"*50)
#         print()
#         print()
#         if concept_classification:
#             correct, full_answer = answer_and_grade_benchmark_question(question, args.model, answer, args.benchmark == "mmlu")
#             if correct:
#                 print("#"*50)
#                 print("TRUE: GENERATING SUBQUESTIONS")
#                 break
#         number += 1
#     # Generate subquestions.
#     max_attempts = 10
#     while max_attempts > 0:
#         subquestions = generate_subquestions(question, concept, args.model, args.num_subquestions)
#         print("-"*50)
#         print(subquestions[0])
#         if len(subquestions) == args.num_subquestions:
#             break
#         max_attempts -= 1

#     # Create a folder for saving all the information for this trial
#     trial_dir = f"results/{args.model}/{args.benchmark}/{trial_index}/"
#     os.makedirs(trial_dir, exist_ok=True)

#     # Save the original question, concept, and answer
#     original_question_info = {
#         "question": question,
#         "concept": concept,
#         "subject": subject,
#         "original_answer": answer
#     }
#     with open(os.path.join(trial_dir, "original_question.json"), "w") as f:
#         json.dump(original_question_info, f)

#     # Process each subquestion
#     subquestion_bar = tqdm(enumerate(subquestions), total=len(subquestions), desc="Subquestions")
#     for index, subquestion in subquestion_bar:
#         subquestion_dir = os.path.join(trial_dir, f"subquestion_{index}/")
#         os.makedirs(subquestion_dir, exist_ok=True)

#         # Save subquestion text
#         with open(os.path.join(subquestion_dir, "subquestion.txt"), "w") as f:
#             f.write(subquestion)
        
#         # Get answers for subquestion
#         extracted_answer = answer_open_ended_question(subquestion, args.model)
#         _, answer_with_error = edit_to_introduce_error(subquestion, extracted_answer, args.model)

#         # Save answers
#         answers_info = {
#             "extracted_answer": extracted_answer,
#             "answer_with_error": answer_with_error
#         }
#         with open(os.path.join(subquestion_dir, "answers.json"), "w") as f:
#             json.dump(answers_info, f)

#         # Grade the answers
#         expected_answers = ["correct", "incorrect"]
#         all_answers = [extracted_answer, answer_with_error]
#         for i, answer in enumerate(all_answers):
#             judge_answer, full_judge_answer = grade_open_ended_question(subquestion, answer, args.model)

#             # Save judge evaluations for the two answers
#             judge_info = {
#                 "answer": answer,
#                 "judge_answer": judge_answer,
#                 "full_judge_answer": full_judge_answer,
#                 "expected_answer": expected_answers[i]
#             }
#             judge_eval_dir = os.path.join(subquestion_dir, "judge_eval/")
#             os.makedirs(judge_eval_dir, exist_ok=True)
#             with open(os.path.join(judge_eval_dir, f"judge_{i}.json"), "w") as f:
#                 json.dump(judge_info, f)

#             # Check coherence and save to overall coherence list
#             coherent = 1 if judge_answer.strip().lower()[:len(expected_answers[i])] == expected_answers[i] else 0
#             category_to_coherence[index_to_category[i]].append(coherent)
#             overall_coherence.append(coherent)

#             log_dict = {
#                 "original_question": question,
#                 "concept": concept,
#                 "subquestion": subquestion,
#                 "answer": answer,
#                 "judge_answer": full_judge_answer,
#                 "category": index_to_category[i],
#                 "expected_answer": expected_answers[i],
#                 "coherent": coherent,
#             }

#             # Save logs for each answer with error and judge evaluation
#             with open(os.path.join(subquestion_dir, f"log_{index}_{i}.json"), "w") as f:
#                 json.dump(log_dict, f)

#     # Calculate the Potemkin rate for this trial
#     potemkin_rate = 2 * (1 - np.mean(overall_coherence))
#     score_per_concept.append(potemkin_rate)
#     score_per_concept_std_err = np.std(score_per_concept) / np.sqrt(len(score_per_concept))
#     bar.set_description(f"Model: {args.model} Potemkin rate (lower bound): {np.mean(score_per_concept):.2f} ({score_per_concept_std_err:.2f}). ")

# # Final Potemkin rate
# print(f"Potemkin rate (lower bound): {np.mean(score_per_concept):.2f}")
